ok compra
ok compra
ok compra
ok compra
<?php
session_start();

echo "<br>";
echo "<br>";
echo $_SESSION["id_comanda"];

?>